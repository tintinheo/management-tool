import { supabase } from "./supabase";

const base = (import.meta.env.VITE_API_BASE_URL as string).replace(/\/$/, "");

export async function api<T>(path: string, init?: RequestInit): Promise<T> {
  const { data } = await supabase.auth.getSession();
  const token = data.session?.access_token;
  if (!token) throw new Error("Not signed in");
  const response = await fetch(`${base}${path}`, {
    ...init,
    headers: {
      authorization: `Bearer ${token}`,
      "content-type": "application/json",
      ...(init?.headers ?? {})
    }
  });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(payload?.error ? JSON.stringify(payload.error) : `HTTP ${response.status}`);
  return payload as T;
}
