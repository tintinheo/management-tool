import { useEffect, useState } from "react";
import { useEditor, EditorContent } from "@tiptap/react";
import StarterKit from "@tiptap/starter-kit";
import Placeholder from "@tiptap/extension-placeholder";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { api } from "./api";

type Page = {
  id: string;
  title: string;
  parent_page_id: string | null;
  content_json: unknown;
  updated_at: string;
};

export function PagesPanel({ workspaceId }: { workspaceId: string }) {
  const qc = useQueryClient();
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [title, setTitle] = useState("");

  const pages = useQuery({
    queryKey: ["pages", workspaceId],
    queryFn: () => api<{ data: Page[] }>(`/api/v1/pages?workspaceId=${workspaceId}`)
  });

  useEffect(() => {
    if (!selectedId && pages.data?.data[0]) setSelectedId(pages.data.data[0].id);
  }, [pages.data, selectedId]);

  const page = useQuery({
    queryKey: ["page", selectedId],
    enabled: Boolean(selectedId),
    queryFn: () => api<{ data: Page }>(`/api/v1/pages/${selectedId}`)
  });

  const editor = useEditor({
    extensions: [StarterKit, Placeholder.configure({ placeholder: "Write notes, decisions, links, and context…" })],
    content: { type: "doc", content: [] },
    editorProps: { attributes: { class: "editor-content" } }
  });

  useEffect(() => {
    if (!editor || !page.data?.data) return;
    setTitle(page.data.data.title);
    editor.commands.setContent(page.data.data.content_json || { type: "doc", content: [] }, { emitUpdate: false });
  }, [editor, page.data]);

  const createPage = useMutation({
    mutationFn: () => api<{ data: Page }>("/api/v1/pages", {
      method: "POST",
      body: JSON.stringify({ workspaceId, title: "Untitled", contentJson: { type: "doc", content: [] } })
    }),
    onSuccess: async ({ data }) => {
      await qc.invalidateQueries({ queryKey: ["pages", workspaceId] });
      setSelectedId(data.id);
    }
  });

  const savePage = useMutation({
    mutationFn: () => api<{ data: Page }>(`/api/v1/pages/${selectedId}`, {
      method: "PATCH",
      body: JSON.stringify({ title: title || "Untitled", contentJson: editor?.getJSON() })
    }),
    onSuccess: async () => {
      await Promise.all([
        qc.invalidateQueries({ queryKey: ["pages", workspaceId] }),
        qc.invalidateQueries({ queryKey: ["page", selectedId] })
      ]);
    }
  });

  return (
    <div className="pages-layout">
      <section className="page-list card">
        <div className="page-list-heading">
          <strong>Pages</strong>
          <button onClick={() => createPage.mutate()} disabled={createPage.isPending}>+</button>
        </div>
        {pages.data?.data.map((item) => (
          <button key={item.id} className={selectedId === item.id ? "page-item active" : "page-item"} onClick={() => setSelectedId(item.id)}>
            <span>▤</span>{item.title}
          </button>
        ))}
        {!pages.isLoading && !pages.data?.data.length && <p className="muted page-empty">No pages yet.</p>}
      </section>

      <section className="page-editor card">
        {!selectedId ? (
          <div className="empty">Create a page to start writing.</div>
        ) : (
          <>
            <div className="page-editor-toolbar">
              <input className="page-title" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Untitled" />
              <button className="primary" onClick={() => savePage.mutate()} disabled={savePage.isPending || !editor}>Save</button>
            </div>
            <EditorContent editor={editor} />
          </>
        )}
      </section>
    </div>
  );
}
