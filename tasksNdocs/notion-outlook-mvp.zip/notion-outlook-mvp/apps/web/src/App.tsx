import { useEffect, useMemo, useState } from "react";
import type { Session } from "@supabase/supabase-js";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "./supabase";
import { api } from "./api";
import { PagesPanel } from "./PagesPanel";

type Task = {
  id: string;
  title: string;
  status: string;
  priority: string;
  due_source: "MANUAL" | "OUTLOOK";
  due_at: string | null;
  due_date: string | null;
  reminder_enabled: boolean;
  reminder_offset_minutes: number | null;
  outlook_event_links?: Array<{ id: string; event_subject: string; sync_status: string }>;
};

type Event = { id: string; subject: string; start: { dateTime: string; timeZone: string }; isAllDay: boolean };

type WorkspaceMembership = { workspace_id: string; role: string; workspaces: { id: string; name: string } };

export function App() {
  const [session, setSession] = useState<Session | null>(null);
  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => setSession(data.session));
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, next) => setSession(next));
    return () => subscription.unsubscribe();
  }, []);
  if (!session) return <Login />;
  return <Workspace session={session} />;
}

function Login() {
  const [email, setEmail] = useState("");
  const [message, setMessage] = useState("");
  const magicLink = async () => {
    const { error } = await supabase.auth.signInWithOtp({ email, options: { emailRedirectTo: window.location.origin } });
    setMessage(error ? error.message : "Check your email for the sign-in link.");
  };
  const microsoft = async () => {
    const { error } = await supabase.auth.signInWithOAuth({ provider: "azure", options: { redirectTo: window.location.origin, scopes: "email" } });
    if (error) setMessage(error.message);
  };
  return (
    <main className="login-shell">
      <section className="card login-card">
        <h1>Workspace</h1>
        <p className="muted">Notes, tasks, reminders, and a shared Outlook calendar.</p>
        <button className="primary" onClick={microsoft}>Continue with Microsoft</button>
        <div className="divider">or</div>
        <input value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" type="email" />
        <button onClick={magicLink}>Email me a magic link</button>
        {message && <p className="muted">{message}</p>}
      </section>
    </main>
  );
}

function Workspace({ session }: { session: Session }) {
  const qc = useQueryClient();
  const [workspaceId, setWorkspaceId] = useState<string | null>(null);
  const [title, setTitle] = useState("");
  const [eventSearch, setEventSearch] = useState("");
  const [linkingTaskId, setLinkingTaskId] = useState<string | null>(null);
  const [view, setView] = useState<"tasks" | "pages">("tasks");

  const memberships = useQuery({
    queryKey: ["memberships", session.user.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("workspace_members")
        .select("workspace_id,role,workspaces(id,name)")
        .eq("user_id", session.user.id);
      if (error) throw error;
      return data as unknown as WorkspaceMembership[];
    }
  });

  useEffect(() => {
    if (!workspaceId && memberships.data?.[0]) setWorkspaceId(memberships.data[0].workspace_id);
  }, [memberships.data, workspaceId]);

  const tasks = useQuery({
    queryKey: ["tasks", workspaceId],
    enabled: Boolean(workspaceId),
    queryFn: () => api<{ data: Task[] }>(`/api/v1/tasks?workspaceId=${workspaceId}`)
  });

  const events = useQuery({
    queryKey: ["events", workspaceId, eventSearch],
    enabled: Boolean(workspaceId && linkingTaskId),
    queryFn: () => api<{ data: Event[] }>(`/api/v1/outlook/events?workspaceId=${workspaceId}&search=${encodeURIComponent(eventSearch)}`)
  });

  const create = useMutation({
    mutationFn: () => api("/api/v1/tasks", {
      method: "POST",
      body: JSON.stringify({ workspaceId, title, status: "TODO", priority: "NORMAL", reminderEnabled: true, reminderOffsetMinutes: 60 })
    }),
    onSuccess: () => { setTitle(""); qc.invalidateQueries({ queryKey: ["tasks", workspaceId] }); }
  });

  const link = useMutation({
    mutationFn: ({ taskId, eventId }: { taskId: string; eventId: string }) => api(`/api/v1/tasks/${taskId}/outlook-link`, {
      method: "POST",
      body: JSON.stringify({ eventId })
    }),
    onSuccess: () => { setLinkingTaskId(null); qc.invalidateQueries({ queryKey: ["tasks", workspaceId] }); }
  });

  const currentName = useMemo(() => memberships.data?.find((m) => m.workspace_id === workspaceId)?.workspaces?.name ?? "Workspace", [memberships.data, workspaceId]);
  if (memberships.isLoading) return <main className="shell">Loading…</main>;
  if (!memberships.data?.length) return <NoWorkspace userId={session.user.id} />;

  return (
    <div className="app-shell">
      <aside>
        <div className="brand">{currentName}</div>
        <select value={workspaceId ?? ""} onChange={(e) => setWorkspaceId(e.target.value)}>
          {memberships.data.map((m) => <option key={m.workspace_id} value={m.workspace_id}>{m.workspaces.name}</option>)}
        </select>
        <nav><button className={view === "tasks" ? "nav-item active" : "nav-item"} onClick={() => setView("tasks")}>Tasks</button><button className={view === "pages" ? "nav-item active" : "nav-item"} onClick={() => setView("pages")}>Pages</button><span>Calendar</span><span>Settings</span></nav>
        <button className="ghost" onClick={() => supabase.auth.signOut()}>Sign out</button>
      </aside>
      <main className="content">
        {view === "tasks" ? (
          <>
            <header><div><h1>Tasks</h1><p className="muted">Outlook-linked tasks follow the shared calendar.</p></div></header>
            <section className="card create-row">
              <input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Add a task…" onKeyDown={(e) => { if (e.key === "Enter" && title.trim()) create.mutate(); }} />
              <button className="primary" disabled={!title.trim() || create.isPending} onClick={() => create.mutate()}>Add task</button>
            </section>
            <section className="task-list">
              {tasks.data?.data.map((task) => (
                <article className="card task" key={task.id}>
                  <div><h3>{task.title}</h3><div className="chips"><span>{task.status}</span><span>{task.priority}</span>{task.due_source === "OUTLOOK" && <span>↻ Outlook</span>}</div></div>
                  <div className="task-meta">
                    <div>{task.due_date ?? (task.due_at ? new Date(task.due_at).toLocaleString() : "No due date")}</div>
                    {task.outlook_event_links?.[0] && <div className="muted">{task.outlook_event_links[0].event_subject} · {task.outlook_event_links[0].sync_status}</div>}
                  </div>
                  <button onClick={() => setLinkingTaskId(task.id)}>{task.due_source === "OUTLOOK" ? "Change event" : "Link Outlook"}</button>
                </article>
              ))}
              {!tasks.isLoading && !tasks.data?.data.length && <div className="empty">Create your first task above.</div>}
            </section>
          </>
        ) : (
          workspaceId && <PagesPanel workspaceId={workspaceId} />
        )}
      </main>
      {view === "tasks" && linkingTaskId && (
        <div className="modal-backdrop" onMouseDown={() => setLinkingTaskId(null)}>
          <section className="card modal" onMouseDown={(e) => e.stopPropagation()}>
            <h2>Choose shared Outlook event</h2>
            <input autoFocus value={eventSearch} onChange={(e) => setEventSearch(e.target.value)} placeholder="Search event subject…" />
            <div className="event-list">
              {events.isLoading && <p>Loading events…</p>}
              {events.data?.data.slice(0, 50).map((event) => (
                <button className="event" key={event.id} onClick={() => link.mutate({ taskId: linkingTaskId, eventId: event.id })}>
                  <strong>{event.subject || "(No title)"}</strong>
                  <span>{event.isAllDay ? event.start.dateTime.slice(0, 10) : new Date(event.start.dateTime).toLocaleString()}</span>
                </button>
              ))}
            </div>
          </section>
        </div>
      )}
    </div>
  );
}

function NoWorkspace({ userId }: { userId: string }) {
  const [name, setName] = useState("My Workspace");
  const [message, setMessage] = useState("No workspace membership exists yet.");
  const create = async () => {
    // Bootstrap convenience for an empty project. Production systems normally gate this behind onboarding policy.
    const { data: workspace, error } = await supabase.from("workspaces").insert({ name, created_by: userId }).select().single();
    if (error) return setMessage(error.message);
    const { error: memberError } = await supabase.from("workspace_members").insert({ workspace_id: workspace.id, user_id: userId, role: "ADMIN" });
    setMessage(memberError ? memberError.message : "Workspace created. Refreshing…");
    if (!memberError) window.location.reload();
  };
  return <main className="login-shell"><section className="card login-card"><h1>Create workspace</h1><p className="muted">{message}</p><input value={name} onChange={(e) => setName(e.target.value)} /><button className="primary" onClick={create}>Create</button></section></main>;
}
