import { describe, expect, it } from "vitest";
import { calculateReminderAt } from "./time";

describe("calculateReminderAt", () => {
  it("subtracts reminder offset", () => {
    expect(calculateReminderAt("2026-07-31T10:00:00.000Z", null, false, 60)).toBe("2026-07-31T09:00:00.000Z");
  });

  it("returns null without offset", () => {
    expect(calculateReminderAt("2026-07-31T10:00:00.000Z", null, false, null)).toBeNull();
  });
});
