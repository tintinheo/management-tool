import type { OutlookEventSummary } from "@app/shared";
import type { Env } from "./env";

type TokenCache = { token: string; expiresAt: number };
let cache: TokenCache | undefined;

async function getGraphToken(env: Env): Promise<string> {
  const now = Date.now();
  if (cache && cache.expiresAt > now + 60_000) return cache.token;

  const body = new URLSearchParams({
    client_id: env.MICROSOFT_CLIENT_ID,
    client_secret: env.MICROSOFT_CLIENT_SECRET,
    grant_type: "client_credentials",
    scope: "https://graph.microsoft.com/.default"
  });

  const response = await fetch(
    `https://login.microsoftonline.com/${encodeURIComponent(env.MICROSOFT_TENANT_ID)}/oauth2/v2.0/token`,
    {
      method: "POST",
      headers: { "content-type": "application/x-www-form-urlencoded" },
      body
    }
  );

  if (!response.ok) throw new Error(`Microsoft token error ${response.status}: ${await response.text()}`);
  const json = (await response.json()) as { access_token: string; expires_in: number };
  cache = { token: json.access_token, expiresAt: now + json.expires_in * 1000 };
  return json.access_token;
}

async function graphFetch<T>(env: Env, path: string, init?: RequestInit): Promise<T> {
  const token = await getGraphToken(env);
  const response = await fetch(`https://graph.microsoft.com/v1.0${path}`, {
    ...init,
    headers: {
      authorization: `Bearer ${token}`,
      accept: "application/json",
      "content-type": "application/json",
      Prefer: 'IdType="ImmutableId"',
      ...(init?.headers ?? {})
    }
  });

  if (!response.ok) {
    const text = await response.text();
    const error = new Error(`Graph ${response.status}: ${text}`) as Error & { status?: number; retryAfter?: string | null };
    error.status = response.status;
    error.retryAfter = response.headers.get("retry-after");
    throw error;
  }

  if (response.status === 204) return undefined as T;
  return (await response.json()) as T;
}

function mailbox(env: Env) {
  return encodeURIComponent(env.MICROSOFT_MAILBOX_UPN);
}

export async function listCalendarEvents(env: Env, start: string, end: string, search?: string) {
  const select = [
    "id",
    "subject",
    "start",
    "end",
    "isAllDay",
    "isCancelled",
    "lastModifiedDateTime",
    "type",
    "seriesMasterId",
    "location",
    "organizer"
  ].join(",");

  const query = new URLSearchParams({
    startDateTime: start,
    endDateTime: end,
    "$select": select,
    "$top": "200"
  });

  // calendarView expands recurring events into concrete occurrences in the selected window.
  const path = `/users/${mailbox(env)}/calendars/${encodeURIComponent(env.MICROSOFT_CALENDAR_ID)}/calendarView?${query}`;
  const result = await graphFetch<{ value: OutlookEventSummary[] }>(env, path);
  const value = result.value ?? [];
  if (!search?.trim()) return value;
  const q = search.toLowerCase();
  return value.filter((event) => event.subject?.toLowerCase().includes(q));
}

export async function getEvent(env: Env, eventId: string) {
  const select = [
    "id",
    "subject",
    "start",
    "end",
    "isAllDay",
    "isCancelled",
    "lastModifiedDateTime",
    "type",
    "seriesMasterId",
    "location",
    "organizer"
  ].join(",");
  return graphFetch<OutlookEventSummary>(
    env,
    `/users/${mailbox(env)}/events/${encodeURIComponent(eventId)}?$select=${encodeURIComponent(select)}`
  );
}

export async function verifyCalendar(env: Env) {
  return graphFetch<{ id: string; name: string; canEdit?: boolean; owner?: unknown }>(
    env,
    `/users/${mailbox(env)}/calendars/${encodeURIComponent(env.MICROSOFT_CALENDAR_ID)}`
  );
}

export interface GraphSubscription {
  id: string;
  resource: string;
  expirationDateTime: string;
}

function subscriptionExpiration(days = 6) {
  return new Date(Date.now() + days * 24 * 60 * 60 * 1000).toISOString();
}

export async function createSubscription(env: Env) {
  return graphFetch<GraphSubscription>(env, "/subscriptions", {
    method: "POST",
    body: JSON.stringify({
      changeType: "created,updated,deleted",
      notificationUrl: `${env.WEBHOOK_BASE_URL.replace(/\/$/, "")}/webhooks/microsoft/events`,
      lifecycleNotificationUrl: `${env.WEBHOOK_BASE_URL.replace(/\/$/, "")}/webhooks/microsoft/lifecycle`,
      resource: `/users/${env.MICROSOFT_MAILBOX_UPN}/events`,
      expirationDateTime: subscriptionExpiration(),
      clientState: env.GRAPH_CLIENT_STATE
    })
  });
}

export async function renewSubscription(env: Env, subscriptionId: string) {
  return graphFetch<GraphSubscription>(env, `/subscriptions/${encodeURIComponent(subscriptionId)}`, {
    method: "PATCH",
    body: JSON.stringify({ expirationDateTime: subscriptionExpiration() })
  });
}
