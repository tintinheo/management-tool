import type { OutlookEventSummary } from "@app/shared";
import type { Env } from "./env";
import { serviceDb } from "./db";
import { getEvent, createSubscription, renewSubscription } from "./graph";
import { calculateReminderAt, eventDueFields, graphDateTimeToIso } from "./time";

function toIso(value?: string | null) {
  return value ? new Date(value).toISOString() : null;
}

export async function syncEventById(env: Env, eventId: string, changeType?: string) {
  const db = serviceDb(env);
  const { data: links, error: linkError } = await db
    .from("outlook_event_links")
    .select("id,task_id,event_id,event_last_modified_at,sync_status")
    .eq("event_id", eventId)
    .is("deleted_at", null);
  if (linkError) throw new Error(linkError.message);
  if (!links?.length) return { matched: 0, updated: 0 };

  if (changeType === "deleted") {
    for (const link of links) await markDeleted(env, link.id, link.task_id);
    return { matched: links.length, updated: links.length };
  }

  let event: OutlookEventSummary;
  try {
    event = await getEvent(env, eventId);
  } catch (error) {
    const status = (error as { status?: number }).status;
    if (status === 404) {
      for (const link of links) await markDeleted(env, link.id, link.task_id);
      return { matched: links.length, updated: links.length };
    }
    throw error;
  }

  let updated = 0;
  for (const link of links) {
    const stored = toIso(link.event_last_modified_at);
    const incoming = toIso(event.lastModifiedDateTime);
    if (stored && incoming && incoming < stored) continue;
    await applyEventToLink(env, link.id, link.task_id, event);
    updated += 1;
  }
  return { matched: links.length, updated };
}

export async function syncLinkById(env: Env, linkId: string) {
  const db = serviceDb(env);
  const { data: link, error } = await db
    .from("outlook_event_links")
    .select("id,task_id,event_id")
    .eq("id", linkId)
    .maybeSingle();
  if (error) throw new Error(error.message);
  if (!link) return;
  await syncEventById(env, link.event_id);
}

async function markDeleted(env: Env, linkId: string, taskId: string) {
  const db = serviceDb(env);
  const now = new Date().toISOString();
  const { error } = await db.rpc("apply_outlook_event_deletion", {
    p_link_id: linkId,
    p_task_id: taskId,
    p_sync_time: now
  });
  if (error) throw new Error(error.message);
}

export async function applyEventToLink(env: Env, linkId: string, taskId: string, event: OutlookEventSummary) {
  const db = serviceDb(env);
  const { data: task, error: taskError } = await db
    .from("tasks")
    .select("id,workspace_id,reminder_enabled,reminder_offset_minutes")
    .eq("id", taskId)
    .maybeSingle();
  if (taskError) throw new Error(taskError.message);
  if (!task) return;

  const due = eventDueFields(event);
  const reminderAt = task.reminder_enabled
    ? calculateReminderAt(due.due_at, due.due_date, due.due_is_all_day, task.reminder_offset_minutes)
    : null;

  const { error } = await db.rpc("apply_outlook_event_sync", {
    p_link_id: linkId,
    p_task_id: taskId,
    p_event_subject: event.subject ?? "",
    p_event_start_at: due.due_at,
    p_event_end_at: graphDateTimeToIso(event.end?.dateTime, event.end?.timeZone),
    p_event_timezone: event.start?.timeZone ?? null,
    p_is_all_day: Boolean(event.isAllDay),
    p_is_cancelled: Boolean(event.isCancelled),
    p_event_type: event.type ?? null,
    p_series_master_id: event.seriesMasterId ?? null,
    p_event_last_modified_at: event.lastModifiedDateTime,
    p_due_at: due.due_at,
    p_due_date: due.due_date,
    p_due_is_all_day: due.due_is_all_day,
    p_due_timezone: due.due_timezone,
    p_reminder_at: reminderAt,
    p_sync_time: new Date().toISOString()
  });
  if (error) throw new Error(error.message);
}

export async function queueReconciliation(env: Env) {
  const db = serviceDb(env);
  const { data, error } = await db
    .from("outlook_event_links")
    .select("id")
    .in("sync_status", ["ACTIVE", "EVENT_CANCELLED", "SYNC_ERROR", "EVENT_NOT_FOUND"])
    .is("deleted_at", null)
    .limit(1000);
  if (error) throw new Error(error.message);
  if (!data?.length) return 0;
  for (let i = 0; i < data.length; i += 100) {
    const chunk = data.slice(i, i + 100);
    await env.CALENDAR_SYNC_QUEUE.sendBatch(
      chunk.map((row) => ({
        body: { kind: "reconcile-event" as const, linkId: row.id, receivedAt: new Date().toISOString() }
      }))
    );
  }
  return data.length;
}

export async function ensureGraphSubscription(env: Env) {
  const db = serviceDb(env);
  const { data: integration, error } = await db
    .from("outlook_integrations")
    .select("id,workspace_id")
    .eq("mailbox_upn", env.MICROSOFT_MAILBOX_UPN)
    .eq("calendar_id", env.MICROSOFT_CALENDAR_ID)
    .maybeSingle();
  if (error) throw new Error(error.message);
  if (!integration) throw new Error("Outlook integration row is not configured");

  const { data: existing, error: subError } = await db
    .from("graph_subscriptions")
    .select("id,graph_subscription_id,expires_at,status")
    .eq("outlook_integration_id", integration.id)
    .eq("status", "ACTIVE")
    .order("expires_at", { ascending: false })
    .limit(1)
    .maybeSingle();
  if (subError) throw new Error(subError.message);

  const renewBefore = Date.now() + 48 * 60 * 60 * 1000;
  if (existing && new Date(existing.expires_at).getTime() > renewBefore) return existing;

  if (existing) {
    try {
      const renewed = await renewSubscription(env, existing.graph_subscription_id);
      const { error: updateError } = await db
        .from("graph_subscriptions")
        .update({ expires_at: renewed.expirationDateTime, last_renewed_at: new Date().toISOString() })
        .eq("id", existing.id);
      if (updateError) throw new Error(updateError.message);
      return renewed;
    } catch {
      await db.from("graph_subscriptions").update({ status: "REMOVED" }).eq("id", existing.id);
    }
  }

  const created = await createSubscription(env);
  const hash = await sha256(env.GRAPH_CLIENT_STATE);
  const { error: insertError } = await db.from("graph_subscriptions").insert({
    outlook_integration_id: integration.id,
    graph_subscription_id: created.id,
    resource: created.resource,
    client_state_hash: hash,
    expires_at: created.expirationDateTime,
    status: "ACTIVE",
    last_renewed_at: new Date().toISOString()
  });
  if (insertError) throw new Error(insertError.message);
  return created;
}

async function sha256(value: string) {
  const bytes = new TextEncoder().encode(value);
  const digest = await crypto.subtle.digest("SHA-256", bytes);
  return [...new Uint8Array(digest)].map((b) => b.toString(16).padStart(2, "0")).join("");
}
