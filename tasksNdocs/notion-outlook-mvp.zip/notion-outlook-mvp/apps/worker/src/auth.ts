import type { Context, Next } from "hono";
import type { Env } from "./env";
import { authClient, serviceDb } from "./db";

export type AppVariables = {
  userId: string;
  email?: string;
};

export async function requireAuth(c: Context<{ Bindings: Env; Variables: AppVariables }>, next: Next) {
  const header = c.req.header("authorization");
  if (!header?.startsWith("Bearer ")) return c.json({ error: "UNAUTHORIZED" }, 401);

  const token = header.slice("Bearer ".length).trim();
  const client = authClient(c.env);
  const { data, error } = await client.auth.getClaims(token);
  if (error || !data?.claims?.sub) return c.json({ error: "UNAUTHORIZED" }, 401);

  c.set("userId", String(data.claims.sub));
  const email = data.claims.email;
  if (typeof email === "string") c.set("email", email);
  await next();
}

export async function requireWorkspaceRole(
  env: Env,
  workspaceId: string,
  userId: string,
  allowed: Array<"ADMIN" | "MEMBER" | "VIEWER">
) {
  const db = serviceDb(env);
  const { data, error } = await db
    .from("workspace_members")
    .select("role")
    .eq("workspace_id", workspaceId)
    .eq("user_id", userId)
    .maybeSingle();

  if (error) throw new Error(`membership lookup failed: ${error.message}`);
  if (!data || !allowed.includes(data.role)) return false;
  return true;
}
