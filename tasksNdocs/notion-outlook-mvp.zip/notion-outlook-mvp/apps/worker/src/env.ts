import type { CalendarSyncMessage } from "@app/shared";

export interface Env {
  SUPABASE_URL: string;
  SUPABASE_ANON_KEY: string;
  SUPABASE_SERVICE_ROLE_KEY: string;
  MICROSOFT_TENANT_ID: string;
  MICROSOFT_CLIENT_ID: string;
  MICROSOFT_CLIENT_SECRET: string;
  MICROSOFT_MAILBOX_UPN: string;
  MICROSOFT_CALENDAR_ID: string;
  GRAPH_CLIENT_STATE: string;
  WEBHOOK_BASE_URL: string;
  RESEND_API_KEY?: string;
  REMINDER_FROM_EMAIL?: string;
  ENVIRONMENT?: string;
  CALENDAR_SYNC_QUEUE: Queue<CalendarSyncMessage>;
}
