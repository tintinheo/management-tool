import { Hono } from "hono";
import type { GraphChangeNotification } from "@app/shared";
import type { Env } from "./env";
import { serviceDb } from "./db";
import { queueReconciliation } from "./outlook-sync";

export const webhooks = new Hono<{ Bindings: Env }>();

webhooks.post("/webhooks/microsoft/events", async (c) => {
  const token = c.req.query("validationToken");
  if (token) return c.text(token, 200, { "content-type": "text/plain" });

  const body = await c.req.json<{ value?: GraphChangeNotification[] }>();
  for (const notification of body.value ?? []) {
    if (notification.clientState !== c.env.GRAPH_CLIENT_STATE) {
      console.warn("Rejected Microsoft notification with invalid clientState");
      continue;
    }
    const eventId = notification.resourceData?.id;
    if (!eventId) continue;
    await c.env.CALENDAR_SYNC_QUEUE.send({
      kind: "event-change",
      subscriptionId: notification.subscriptionId,
      eventId,
      changeType: notification.changeType,
      receivedAt: new Date().toISOString()
    });
  }
  return c.body(null, 202);
});

webhooks.post("/webhooks/microsoft/lifecycle", async (c) => {
  const token = c.req.query("validationToken");
  if (token) return c.text(token, 200, { "content-type": "text/plain" });

  const body = await c.req.json<{ value?: Array<GraphChangeNotification & { lifecycleEvent?: string }> }>();
  const db = serviceDb(c.env);
  for (const notification of body.value ?? []) {
    if (notification.clientState !== c.env.GRAPH_CLIENT_STATE) continue;
    if (notification.lifecycleEvent === "missed") await queueReconciliation(c.env);
    if (notification.lifecycleEvent === "subscriptionRemoved") {
      await db.from("graph_subscriptions").update({ status: "REMOVED" }).eq("graph_subscription_id", notification.subscriptionId);
      await queueReconciliation(c.env);
    }
    if (notification.lifecycleEvent === "reauthorizationRequired") {
      await db.from("graph_subscriptions").update({ status: "REAUTHORIZE" }).eq("graph_subscription_id", notification.subscriptionId);
    }
  }
  return c.body(null, 202);
});
