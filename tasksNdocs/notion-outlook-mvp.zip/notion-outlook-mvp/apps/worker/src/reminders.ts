import type { Env } from "./env";
import { serviceDb } from "./db";

export async function processDueReminders(env: Env) {
  const db = serviceDb(env);
  const now = new Date().toISOString();
  const { data: tasks, error } = await db
    .from("tasks")
    .select("id,workspace_id,title,assignee_id,due_at,due_date,due_is_all_day,reminder_at,reminder_version,status")
    .eq("reminder_enabled", true)
    .is("reminder_sent_at", null)
    .lte("reminder_at", now)
    .not("status", "in", "(DONE,CANCELLED)")
    .order("reminder_at", { ascending: true })
    .limit(100);
  if (error) throw new Error(error.message);

  let sent = 0;
  for (const task of tasks ?? []) {
    // Atomic claim prevents duplicate cron executions from sending twice.
    const { data: claimed, error: claimError } = await db.rpc("claim_task_reminder", {
      p_task_id: task.id,
      p_expected_version: task.reminder_version,
      p_claimed_at: now
    });
    if (claimError || !claimed) continue;

    const { data: profile } = task.assignee_id
      ? await db.from("profiles").select("email,display_name").eq("id", task.assignee_id).maybeSingle()
      : { data: null };

    await db.from("notifications").insert({
      workspace_id: task.workspace_id,
      user_id: task.assignee_id,
      task_id: task.id,
      type: "TASK_REMINDER",
      title: `Task reminder: ${task.title}`,
      message: task.due_is_all_day ? `Due ${task.due_date}` : `Due ${task.due_at}`
    });

    if (profile?.email && env.RESEND_API_KEY && env.REMINDER_FROM_EMAIL) {
      const response = await fetch("https://api.resend.com/emails", {
        method: "POST",
        headers: {
          authorization: `Bearer ${env.RESEND_API_KEY}`,
          "content-type": "application/json"
        },
        body: JSON.stringify({
          from: env.REMINDER_FROM_EMAIL,
          to: [profile.email],
          subject: `Task reminder: ${task.title}`,
          text: `${task.title}\n\nDue: ${task.due_is_all_day ? task.due_date : task.due_at}`
        })
      });
      if (!response.ok) console.error("Resend failed", response.status, await response.text());
    }
    sent += 1;
  }
  return sent;
}
