import type { OutlookEventSummary } from "@app/shared";

export function graphDateTimeToIso(dateTime: string | null | undefined, timeZone?: string | null) {
  if (!dateTime) return null;
  const hasOffset = /(?:Z|[+-]\d{2}:\d{2})$/i.test(dateTime);
  const candidate = hasOffset || !timeZone || timeZone.toUpperCase() !== "UTC" ? dateTime : `${dateTime}Z`;
  const parsed = new Date(candidate);
  if (Number.isNaN(parsed.getTime())) throw new Error(`Unsupported Graph dateTime value: ${dateTime} (${timeZone ?? "unknown timezone"})`);
  return parsed.toISOString();
}

export function eventDueFields(event: OutlookEventSummary) {
  if (event.isAllDay) {
    return {
      due_at: null,
      due_date: event.start.dateTime.slice(0, 10),
      due_is_all_day: true,
      due_timezone: event.start.timeZone
    };
  }

  return {
    due_at: graphDateTimeToIso(event.start.dateTime, event.start.timeZone),
    due_date: null,
    due_is_all_day: false,
    due_timezone: event.start.timeZone
  };
}

export function calculateReminderAt(
  dueAt: string | null,
  dueDate: string | null,
  isAllDay: boolean,
  offsetMinutes: number | null
) {
  if (offsetMinutes == null) return null;
  if (isAllDay && dueDate) {
    // MVP convention: all-day events are treated as 09:00 UTC for reminder calculation.
    // Make this workspace-configurable before relying on all-day reminders across regions.
    const base = new Date(`${dueDate}T09:00:00Z`);
    return new Date(base.getTime() - offsetMinutes * 60_000).toISOString();
  }
  if (!dueAt) return null;
  const base = new Date(dueAt);
  if (Number.isNaN(base.getTime())) return null;
  return new Date(base.getTime() - offsetMinutes * 60_000).toISOString();
}
