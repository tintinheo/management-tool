import { Hono } from "hono";
import type { CalendarSyncMessage } from "@app/shared";
import type { Env } from "./env";
import { api } from "./routes";
import { webhooks } from "./webhooks";
import { ensureGraphSubscription, queueReconciliation, syncEventById, syncLinkById } from "./outlook-sync";
import { processDueReminders } from "./reminders";

const app = new Hono<{ Bindings: Env }>();
app.route("/", api);
app.route("/", webhooks);
app.onError((error, c) => {
  console.error(error);
  return c.json({ error: "INTERNAL_ERROR", message: error.message }, 500);
});

export default {
  fetch: app.fetch,

  async queue(batch: MessageBatch<CalendarSyncMessage>, env: Env) {
    for (const message of batch.messages) {
      try {
        const job = message.body;
        if (job.kind === "event-change") {
          await syncEventById(env, job.eventId, job.changeType);
        } else if (job.kind === "reconcile-event") {
          await syncLinkById(env, job.linkId);
        }
        message.ack();
      } catch (error) {
        console.error("Queue job failed", message.body, error);
        message.retry();
      }
    }
  },

  async scheduled(controller: ScheduledController, env: Env, ctx: ExecutionContext) {
    if (controller.cron === "* * * * *") {
      ctx.waitUntil(processDueReminders(env));
      return;
    }
    if (controller.cron === "*/15 * * * *") {
      ctx.waitUntil(queueReconciliation(env));
      return;
    }
    if (controller.cron === "0 2 * * *") {
      ctx.waitUntil(ensureGraphSubscription(env));
    }
  }
};
