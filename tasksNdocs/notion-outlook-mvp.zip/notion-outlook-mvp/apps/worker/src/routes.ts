import { Hono } from "hono";
import { cors } from "hono/cors";
import { CreatePageSchema, CreateTaskSchema, OutlookLinkSchema, UpdateTaskSchema } from "@app/shared";
import type { Env } from "./env";
import type { AppVariables } from "./auth";
import { requireAuth, requireWorkspaceRole } from "./auth";
import { serviceDb } from "./db";
import { getEvent, listCalendarEvents, verifyCalendar } from "./graph";
import { calculateReminderAt, eventDueFields, graphDateTimeToIso } from "./time";
import { ensureGraphSubscription, queueReconciliation } from "./outlook-sync";

export const api = new Hono<{ Bindings: Env; Variables: AppVariables }>();

api.use("*", cors({ origin: "*", allowHeaders: ["Authorization", "Content-Type"] }));
api.get("/health", (c) => c.json({ ok: true, service: "notion-outlook-api" }));
api.use("/api/*", requireAuth);

api.get("/api/v1/pages", async (c) => {
  const workspaceId = c.req.query("workspaceId");
  if (!workspaceId) return c.json({ error: "workspaceId is required" }, 400);
  if (!(await requireWorkspaceRole(c.env, workspaceId, c.get("userId"), ["ADMIN", "MEMBER", "VIEWER"]))) {
    return c.json({ error: "FORBIDDEN" }, 403);
  }
  const db = serviceDb(c.env);
  const { data, error } = await db
    .from("pages")
    .select("*")
    .eq("workspace_id", workspaceId)
    .is("deleted_at", null)
    .order("updated_at", { ascending: false });
  if (error) return c.json({ error: error.message }, 500);
  return c.json({ data });
});

api.post("/api/v1/pages", async (c) => {
  const parsed = CreatePageSchema.safeParse(await c.req.json());
  if (!parsed.success) return c.json({ error: parsed.error.flatten() }, 400);
  const body = parsed.data;
  if (!(await requireWorkspaceRole(c.env, body.workspaceId, c.get("userId"), ["ADMIN", "MEMBER"]))) {
    return c.json({ error: "FORBIDDEN" }, 403);
  }
  const db = serviceDb(c.env);
  const { data, error } = await db
    .from("pages")
    .insert({
      workspace_id: body.workspaceId,
      parent_page_id: body.parentPageId ?? null,
      title: body.title,
      content_json: body.contentJson ?? { type: "doc", content: [] },
      created_by: c.get("userId"),
      updated_by: c.get("userId")
    })
    .select()
    .single();
  if (error) return c.json({ error: error.message }, 500);
  return c.json({ data }, 201);
});


api.get("/api/v1/pages/:id", async (c) => {
  const db = serviceDb(c.env);
  const { data, error } = await db.from("pages").select("*").eq("id", c.req.param("id")).is("deleted_at", null).maybeSingle();
  if (error) return c.json({ error: error.message }, 500);
  if (!data) return c.json({ error: "NOT_FOUND" }, 404);
  if (!(await requireWorkspaceRole(c.env, data.workspace_id, c.get("userId"), ["ADMIN", "MEMBER", "VIEWER"]))) {
    return c.json({ error: "FORBIDDEN" }, 403);
  }
  return c.json({ data });
});

api.patch("/api/v1/pages/:id", async (c) => {
  const db = serviceDb(c.env);
  const { data: page } = await db.from("pages").select("id,workspace_id").eq("id", c.req.param("id")).is("deleted_at", null).maybeSingle();
  if (!page) return c.json({ error: "NOT_FOUND" }, 404);
  if (!(await requireWorkspaceRole(c.env, page.workspace_id, c.get("userId"), ["ADMIN", "MEMBER"]))) {
    return c.json({ error: "FORBIDDEN" }, 403);
  }
  const input = await c.req.json<{ title?: string; contentJson?: unknown; parentPageId?: string | null }>();
  const update: Record<string, unknown> = { updated_by: c.get("userId"), updated_at: new Date().toISOString() };
  if (input.title !== undefined) update.title = input.title.trim();
  if (input.contentJson !== undefined) update.content_json = input.contentJson;
  if (input.parentPageId !== undefined) update.parent_page_id = input.parentPageId;
  const { data, error } = await db.from("pages").update(update).eq("id", page.id).select().single();
  if (error) return c.json({ error: error.message }, 500);
  return c.json({ data });
});

api.get("/api/v1/tasks", async (c) => {
  const workspaceId = c.req.query("workspaceId");
  if (!workspaceId) return c.json({ error: "workspaceId is required" }, 400);
  if (!(await requireWorkspaceRole(c.env, workspaceId, c.get("userId"), ["ADMIN", "MEMBER", "VIEWER"]))) {
    return c.json({ error: "FORBIDDEN" }, 403);
  }
  const db = serviceDb(c.env);
  let query = db
    .from("tasks")
    .select("*,outlook_event_links(*)")
    .eq("workspace_id", workspaceId)
    .is("deleted_at", null)
    .order("created_at", { ascending: false });
  const status = c.req.query("status");
  if (status) query = query.eq("status", status);
  const { data, error } = await query;
  if (error) return c.json({ error: error.message }, 500);
  return c.json({ data });
});

api.post("/api/v1/tasks", async (c) => {
  const parsed = CreateTaskSchema.safeParse(await c.req.json());
  if (!parsed.success) return c.json({ error: parsed.error.flatten() }, 400);
  const body = parsed.data;
  if (!(await requireWorkspaceRole(c.env, body.workspaceId, c.get("userId"), ["ADMIN", "MEMBER"]))) {
    return c.json({ error: "FORBIDDEN" }, 403);
  }
  const reminderAt = body.reminderEnabled
    ? calculateReminderAt(body.dueAt ?? null, body.dueDate ?? null, body.dueIsAllDay, body.reminderOffsetMinutes ?? null)
    : null;
  const db = serviceDb(c.env);
  const { data, error } = await db
    .from("tasks")
    .insert({
      workspace_id: body.workspaceId,
      page_id: body.pageId ?? null,
      title: body.title,
      description: body.description,
      status: body.status,
      priority: body.priority,
      assignee_id: body.assigneeId ?? null,
      due_source: "MANUAL",
      due_at: body.dueAt ?? null,
      due_date: body.dueDate ?? null,
      due_is_all_day: body.dueIsAllDay,
      due_timezone: body.dueTimezone ?? null,
      reminder_enabled: body.reminderEnabled,
      reminder_offset_minutes: body.reminderOffsetMinutes ?? null,
      reminder_at: reminderAt,
      created_by: c.get("userId"),
      updated_by: c.get("userId")
    })
    .select()
    .single();
  if (error) return c.json({ error: error.message }, 500);
  return c.json({ data }, 201);
});

api.patch("/api/v1/tasks/:id", async (c) => {
  const parsed = UpdateTaskSchema.safeParse(await c.req.json());
  if (!parsed.success) return c.json({ error: parsed.error.flatten() }, 400);
  const db = serviceDb(c.env);
  const { data: task } = await db.from("tasks").select("*").eq("id", c.req.param("id")).maybeSingle();
  if (!task) return c.json({ error: "NOT_FOUND" }, 404);
  if (!(await requireWorkspaceRole(c.env, task.workspace_id, c.get("userId"), ["ADMIN", "MEMBER"]))) {
    return c.json({ error: "FORBIDDEN" }, 403);
  }
  if (task.due_source === "OUTLOOK" && (parsed.data.dueAt !== undefined || parsed.data.dueDate !== undefined)) {
    return c.json({ error: "OUTLOOK_DUE_DATE_IS_READ_ONLY" }, 409);
  }
  const update: Record<string, unknown> = { updated_by: c.get("userId"), updated_at: new Date().toISOString() };
  const map: Record<string, string> = {
    pageId: "page_id", title: "title", description: "description", status: "status", priority: "priority",
    assigneeId: "assignee_id", dueAt: "due_at", dueDate: "due_date", dueIsAllDay: "due_is_all_day",
    dueTimezone: "due_timezone", reminderEnabled: "reminder_enabled", reminderOffsetMinutes: "reminder_offset_minutes"
  };
  for (const [key, value] of Object.entries(parsed.data)) update[map[key] ?? key] = value;
  const dueAt = (update.due_at as string | null | undefined) ?? task.due_at;
  const dueDate = (update.due_date as string | null | undefined) ?? task.due_date;
  const isAllDay = (update.due_is_all_day as boolean | undefined) ?? task.due_is_all_day;
  const enabled = (update.reminder_enabled as boolean | undefined) ?? task.reminder_enabled;
  const offset = (update.reminder_offset_minutes as number | null | undefined) ?? task.reminder_offset_minutes;
  if (parsed.data.reminderEnabled !== undefined || parsed.data.reminderOffsetMinutes !== undefined || parsed.data.dueAt !== undefined || parsed.data.dueDate !== undefined) {
    update.reminder_at = enabled ? calculateReminderAt(dueAt, dueDate, isAllDay, offset) : null;
    update.reminder_version = task.reminder_version + 1;
    update.reminder_sent_at = null;
  }
  const { data, error } = await db.from("tasks").update(update).eq("id", task.id).select().single();
  if (error) return c.json({ error: error.message }, 500);
  return c.json({ data });
});

api.get("/api/v1/outlook/status", async (c) => {
  const workspaceId = c.req.query("workspaceId");
  if (!workspaceId) return c.json({ error: "workspaceId is required" }, 400);
  if (!(await requireWorkspaceRole(c.env, workspaceId, c.get("userId"), ["ADMIN", "MEMBER", "VIEWER"]))) {
    return c.json({ error: "FORBIDDEN" }, 403);
  }
  const db = serviceDb(c.env);
  const { data, error } = await db
    .from("outlook_integrations")
    .select("*,graph_subscriptions(*)")
    .eq("workspace_id", workspaceId)
    .maybeSingle();
  if (error) return c.json({ error: error.message }, 500);
  return c.json({ data });
});

api.get("/api/v1/outlook/events", async (c) => {
  const workspaceId = c.req.query("workspaceId");
  if (!workspaceId) return c.json({ error: "workspaceId is required" }, 400);
  if (!(await requireWorkspaceRole(c.env, workspaceId, c.get("userId"), ["ADMIN", "MEMBER", "VIEWER"]))) {
    return c.json({ error: "FORBIDDEN" }, 403);
  }
  const start = c.req.query("start") ?? new Date(Date.now() - 30 * 86400_000).toISOString();
  const end = c.req.query("end") ?? new Date(Date.now() + 365 * 86400_000).toISOString();
  const data = await listCalendarEvents(c.env, start, end, c.req.query("search"));
  return c.json({ data });
});

api.post("/api/v1/tasks/:id/outlook-link", async (c) => {
  const parsed = OutlookLinkSchema.safeParse(await c.req.json());
  if (!parsed.success) return c.json({ error: parsed.error.flatten() }, 400);
  const db = serviceDb(c.env);
  const { data: task } = await db.from("tasks").select("*").eq("id", c.req.param("id")).maybeSingle();
  if (!task) return c.json({ error: "NOT_FOUND" }, 404);
  if (!(await requireWorkspaceRole(c.env, task.workspace_id, c.get("userId"), ["ADMIN", "MEMBER"]))) {
    return c.json({ error: "FORBIDDEN" }, 403);
  }
  const { data: integration } = await db
    .from("outlook_integrations")
    .select("id")
    .eq("workspace_id", task.workspace_id)
    .maybeSingle();
  if (!integration) return c.json({ error: "OUTLOOK_NOT_CONFIGURED" }, 409);
  const event = await getEvent(c.env, parsed.data.eventId);
  const due = eventDueFields(event);
  const reminderAt = task.reminder_enabled
    ? calculateReminderAt(due.due_at, due.due_date, due.due_is_all_day, task.reminder_offset_minutes)
    : null;
  const { data, error } = await db.rpc("link_task_to_outlook_event", {
    p_task_id: task.id,
    p_integration_id: integration.id,
    p_event_id: event.id,
    p_calendar_id: parsed.data.calendarId ?? c.env.MICROSOFT_CALENDAR_ID,
    p_event_subject: event.subject ?? "",
    p_event_start_at: due.due_at,
    p_event_end_at: graphDateTimeToIso(event.end?.dateTime, event.end?.timeZone),
    p_event_timezone: event.start.timeZone,
    p_is_all_day: Boolean(event.isAllDay),
    p_is_cancelled: Boolean(event.isCancelled),
    p_event_type: event.type ?? null,
    p_series_master_id: event.seriesMasterId ?? null,
    p_event_last_modified_at: event.lastModifiedDateTime,
    p_due_at: due.due_at,
    p_due_date: due.due_date,
    p_due_is_all_day: due.due_is_all_day,
    p_due_timezone: due.due_timezone,
    p_reminder_at: reminderAt,
    p_actor_id: c.get("userId")
  });
  if (error) return c.json({ error: error.message }, 500);
  return c.json({ data });
});

api.delete("/api/v1/tasks/:id/outlook-link", async (c) => {
  const db = serviceDb(c.env);
  const { data: task } = await db.from("tasks").select("*").eq("id", c.req.param("id")).maybeSingle();
  if (!task) return c.json({ error: "NOT_FOUND" }, 404);
  if (!(await requireWorkspaceRole(c.env, task.workspace_id, c.get("userId"), ["ADMIN", "MEMBER"]))) {
    return c.json({ error: "FORBIDDEN" }, 403);
  }
  const { error } = await db.rpc("unlink_task_from_outlook_event", {
    p_task_id: task.id,
    p_actor_id: c.get("userId")
  });
  if (error) return c.json({ error: error.message }, 500);
  return c.json({ ok: true });
});

api.post("/api/v1/admin/outlook/verify", async (c) => {
  const { workspaceId } = await c.req.json<{ workspaceId: string }>();
  if (!(await requireWorkspaceRole(c.env, workspaceId, c.get("userId"), ["ADMIN"]))) return c.json({ error: "FORBIDDEN" }, 403);
  const calendar = await verifyCalendar(c.env);
  const db = serviceDb(c.env);
  const { data, error } = await db.from("outlook_integrations").upsert({
    workspace_id: workspaceId,
    tenant_id: c.env.MICROSOFT_TENANT_ID,
    mailbox_upn: c.env.MICROSOFT_MAILBOX_UPN,
    mailbox_user_id: c.env.MICROSOFT_MAILBOX_UPN,
    calendar_id: c.env.MICROSOFT_CALENDAR_ID,
    calendar_name: calendar.name,
    calendar_type: "SHARED_MAILBOX",
    connection_status: "ACTIVE",
    last_verified_at: new Date().toISOString()
  }, { onConflict: "workspace_id" }).select().single();
  if (error) return c.json({ error: error.message }, 500);
  return c.json({ data });
});

api.post("/api/v1/admin/outlook/resync", async (c) => {
  const { workspaceId } = await c.req.json<{ workspaceId: string }>();
  if (!(await requireWorkspaceRole(c.env, workspaceId, c.get("userId"), ["ADMIN"]))) return c.json({ error: "FORBIDDEN" }, 403);
  return c.json({ queued: await queueReconciliation(c.env) });
});

api.post("/api/v1/admin/outlook/subscription/renew", async (c) => {
  const { workspaceId } = await c.req.json<{ workspaceId: string }>();
  if (!(await requireWorkspaceRole(c.env, workspaceId, c.get("userId"), ["ADMIN"]))) return c.json({ error: "FORBIDDEN" }, 403);
  return c.json({ data: await ensureGraphSubscription(c.env) });
});
