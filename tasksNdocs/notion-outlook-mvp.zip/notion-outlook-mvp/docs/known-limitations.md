# Known MVP Limitations

1. **All-day Outlook events require target-tenant validation.** Microsoft Graph models all-day events as date-based events, but current UTC/timezone behavior can be surprising across tenants and time zones. The starter stores them as `DATE` rather than converting them into a timed UTC due date. Validate the returned date against your actual shared calendar before enabling all-day linking broadly.
2. **One-way calendar authority.** While linked, Outlook controls the task due date. The app does not move Outlook events.
3. **Recurring series.** Link a concrete occurrence, not the series master.
4. **Reconciliation is direct-event based.** Every 15 minutes the MVP verifies linked events. Replace/augment this with Graph delta state at higher scale.
5. **Email reminder delivery is at-most-once in the starter.** The task reminder is atomically claimed before provider delivery. For business-critical email, add a durable notification-outbox table with provider retry state.
6. **Free-tier hosting has no production SLA.** Upgrade database/monitoring plans before the app becomes business critical.
7. **CORS is permissive in the starter.** Restrict it to the deployed frontend origin before production.
8. **Integration configuration is environment driven.** The admin API can verify and store the configured mailbox/calendar, but a full configuration UI is not yet included.
