# Implementation Notes

## Sync invariant

While `tasks.due_source = 'OUTLOOK'`, the app does not accept manual due-date changes. The Outlook event start drives the task due date and the calculated reminder.

## Basic notification path

1. Microsoft Graph POSTs a basic notification.
2. Worker validates `clientState`.
3. Worker enqueues event ID and change type.
4. Queue consumer loads all links for the immutable event ID.
5. For updates, consumer GETs the current event from Graph.
6. PostgreSQL RPC atomically updates event snapshot, task due fields, reminder version, and audit log.
7. For deletes/404, the task is retained and only the link enters `EVENT_DELETED`.

## Why the Worker re-reads Graph

Basic Graph notifications are signals, not authoritative snapshots. Re-reading Graph also collapses rapid changes into the current event state.

## Reconciliation

Every 15 minutes, active links are queued for direct verification. This repairs missed notifications and is intentionally simple for the MVP. At larger scale, add per-calendar delta state.

## Reminder semantics

The database stores a monotonically increasing `reminder_version`. Any due/reminder change resets `reminder_sent_at` and increments the version. Cron uses an atomic PostgreSQL claim function so concurrent schedules cannot send the same version twice.

## Known timezone TODO

Microsoft Graph GET operations return event start/end in UTC when no `Prefer: outlook.timezone` header is supplied. The starter relies on that default for storage, while retaining the returned timezone field. If you later request a non-UTC Outlook timezone, add an explicit Windows-timezone-to-IANA conversion strategy rather than parsing local clock strings implicitly.

## Production hardening TODO

- Restrict allowed CORS origins.
- Add an admin UI for initial integration configuration.
- Add structured logging/alerting.
- Add retry scheduling that honors Graph `Retry-After` precisely.
- Add dead-letter inspection tooling.
- Add browser Realtime subscriptions for task changes.
- Add rich page editor UI around Tiptap; the dependency is included but this starter focuses on the task/calendar critical path.
- Add a separate notification delivery table if email delivery must be exactly-once independently of in-app reminder claiming.
