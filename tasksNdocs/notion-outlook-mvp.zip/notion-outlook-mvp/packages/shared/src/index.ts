import { z } from "zod";

export const TaskStatus = z.enum(["TODO", "IN_PROGRESS", "BLOCKED", "DONE", "CANCELLED"]);
export type TaskStatus = z.infer<typeof TaskStatus>;

export const TaskPriority = z.enum(["LOW", "NORMAL", "HIGH", "URGENT"]);
export type TaskPriority = z.infer<typeof TaskPriority>;

export const WorkspaceRole = z.enum(["ADMIN", "MEMBER", "VIEWER"]);
export type WorkspaceRole = z.infer<typeof WorkspaceRole>;

export const CreatePageSchema = z.object({
  workspaceId: z.string().uuid(),
  parentPageId: z.string().uuid().nullable().optional(),
  title: z.string().trim().min(1).max(200),
  contentJson: z.unknown().optional()
});

export const CreateTaskSchema = z.object({
  workspaceId: z.string().uuid(),
  pageId: z.string().uuid().nullable().optional(),
  title: z.string().trim().min(1).max(300),
  description: z.string().max(20_000).optional().default(""),
  status: TaskStatus.optional().default("TODO"),
  priority: TaskPriority.optional().default("NORMAL"),
  assigneeId: z.string().uuid().nullable().optional(),
  dueAt: z.string().datetime().nullable().optional(),
  dueDate: z.string().date().nullable().optional(),
  dueIsAllDay: z.boolean().optional().default(false),
  dueTimezone: z.string().nullable().optional(),
  reminderEnabled: z.boolean().optional().default(false),
  reminderOffsetMinutes: z.number().int().min(0).max(525_600).nullable().optional()
});

export const UpdateTaskSchema = CreateTaskSchema.omit({ workspaceId: true }).partial();

export const OutlookLinkSchema = z.object({
  eventId: z.string().min(1),
  calendarId: z.string().min(1).optional()
});

export type CreateTaskInput = z.infer<typeof CreateTaskSchema>;
export type UpdateTaskInput = z.infer<typeof UpdateTaskSchema>;

export interface OutlookEventSummary {
  id: string;
  subject: string;
  start: { dateTime: string; timeZone: string };
  end: { dateTime: string; timeZone: string };
  isAllDay: boolean;
  isCancelled: boolean;
  lastModifiedDateTime: string;
  type?: "singleInstance" | "occurrence" | "exception" | "seriesMaster";
  seriesMasterId?: string | null;
  location?: { displayName?: string };
  organizer?: { emailAddress?: { name?: string; address?: string } };
}

export interface GraphChangeNotification {
  subscriptionId: string;
  subscriptionExpirationDateTime: string;
  changeType: "created" | "updated" | "deleted";
  resource: string;
  clientState?: string;
  tenantId?: string;
  resourceData?: {
    id?: string;
    "@odata.id"?: string;
    "@odata.etag"?: string;
    "@odata.type"?: string;
  };
}

export type CalendarSyncMessage =
  | {
      kind: "event-change";
      subscriptionId: string;
      eventId: string;
      changeType: "created" | "updated" | "deleted";
      receivedAt: string;
    }
  | {
      kind: "reconcile-event";
      linkId: string;
      receivedAt: string;
    };
