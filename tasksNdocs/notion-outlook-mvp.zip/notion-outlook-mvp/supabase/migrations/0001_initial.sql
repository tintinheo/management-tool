-- Notion + Shared Outlook Calendar MVP
-- Apply to a fresh Supabase PostgreSQL project.

create extension if not exists pgcrypto;

create type public.workspace_role as enum ('ADMIN','MEMBER','VIEWER');
create type public.task_status as enum ('TODO','IN_PROGRESS','BLOCKED','DONE','CANCELLED');
create type public.task_priority as enum ('LOW','NORMAL','HIGH','URGENT');
create type public.due_source as enum ('MANUAL','OUTLOOK');
create type public.outlook_sync_status as enum ('ACTIVE','EVENT_CANCELLED','EVENT_DELETED','EVENT_NOT_FOUND','AUTH_ERROR','GRAPH_ERROR','SYNC_ERROR','DISCONNECTED');
create type public.graph_subscription_status as enum ('ACTIVE','REMOVED','REAUTHORIZE','ERROR');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text,
  display_name text,
  avatar_url text,
  timezone text not null default 'UTC',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.workspaces (
  id uuid primary key default gen_random_uuid(),
  name text not null check (char_length(name) between 1 and 200),
  timezone text not null default 'UTC',
  created_by uuid not null references public.profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.workspace_members (
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  role public.workspace_role not null default 'MEMBER',
  created_at timestamptz not null default now(),
  primary key (workspace_id, user_id)
);

create table public.pages (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  parent_page_id uuid references public.pages(id) on delete set null,
  title text not null check (char_length(title) between 1 and 200),
  icon text,
  content_json jsonb not null default '{"type":"doc","content":[]}'::jsonb,
  created_by uuid not null references public.profiles(id),
  updated_by uuid not null references public.profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz
);
create index pages_workspace_idx on public.pages(workspace_id, updated_at desc) where deleted_at is null;
create index pages_parent_idx on public.pages(parent_page_id) where deleted_at is null;

create table public.tasks (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  page_id uuid references public.pages(id) on delete set null,
  title text not null check (char_length(title) between 1 and 300),
  description text not null default '',
  status public.task_status not null default 'TODO',
  priority public.task_priority not null default 'NORMAL',
  assignee_id uuid references public.profiles(id) on delete set null,
  due_source public.due_source not null default 'MANUAL',
  due_at timestamptz,
  due_date date,
  due_is_all_day boolean not null default false,
  due_timezone text,
  reminder_enabled boolean not null default false,
  reminder_offset_minutes integer check (reminder_offset_minutes is null or reminder_offset_minutes between 0 and 525600),
  reminder_at timestamptz,
  reminder_version integer not null default 0,
  reminder_sent_at timestamptz,
  created_by uuid not null references public.profiles(id),
  updated_by uuid not null references public.profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz,
  constraint task_due_shape check (
    (due_is_all_day = true and (due_date is not null or (due_at is null and due_date is null))) or
    (due_is_all_day = false)
  )
);
create index tasks_workspace_idx on public.tasks(workspace_id, created_at desc) where deleted_at is null;
create index tasks_assignee_idx on public.tasks(assignee_id) where deleted_at is null;
create index tasks_reminder_idx on public.tasks(reminder_at) where reminder_enabled = true and reminder_sent_at is null and deleted_at is null;

create table public.outlook_integrations (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null unique references public.workspaces(id) on delete cascade,
  tenant_id text not null,
  mailbox_user_id text not null,
  mailbox_upn text not null,
  calendar_id text not null,
  calendar_name text,
  calendar_type text not null default 'SHARED_MAILBOX',
  connection_status text not null default 'ACTIVE',
  last_verified_at timestamptz,
  last_successful_sync_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.graph_subscriptions (
  id uuid primary key default gen_random_uuid(),
  outlook_integration_id uuid not null references public.outlook_integrations(id) on delete cascade,
  graph_subscription_id text not null unique,
  resource text not null,
  client_state_hash text not null,
  expires_at timestamptz not null,
  status public.graph_subscription_status not null default 'ACTIVE',
  last_renewed_at timestamptz,
  last_notification_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index graph_subscription_expiry_idx on public.graph_subscriptions(expires_at) where status = 'ACTIVE';

create table public.outlook_event_links (
  id uuid primary key default gen_random_uuid(),
  task_id uuid not null unique references public.tasks(id) on delete cascade,
  outlook_integration_id uuid not null references public.outlook_integrations(id) on delete cascade,
  event_id text not null,
  calendar_id text not null,
  event_subject text not null default '',
  event_start_at timestamptz,
  event_end_at timestamptz,
  event_timezone text,
  is_all_day boolean not null default false,
  is_cancelled boolean not null default false,
  event_type text,
  series_master_id text,
  event_last_modified_at timestamptz,
  sync_status public.outlook_sync_status not null default 'ACTIVE',
  last_sync_at timestamptz,
  last_error text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz
);
create index outlook_event_link_event_idx on public.outlook_event_links(event_id) where deleted_at is null;

create table public.notifications (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  user_id uuid references public.profiles(id) on delete cascade,
  task_id uuid references public.tasks(id) on delete cascade,
  type text not null,
  title text not null,
  message text not null,
  read_at timestamptz,
  created_at timestamptz not null default now()
);
create index notifications_user_idx on public.notifications(user_id, created_at desc);

create table public.audit_logs (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  actor_type text not null default 'USER',
  actor_id uuid,
  entity_type text not null,
  entity_id uuid,
  action text not null,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
create index audit_workspace_idx on public.audit_logs(workspace_id, created_at desc);

-- Bootstrap profile from Supabase Auth.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles(id, email, display_name, avatar_url)
  values (
    new.id,
    new.email,
    coalesce(new.raw_user_meta_data->>'full_name', new.raw_user_meta_data->>'name', split_part(coalesce(new.email,''), '@', 1)),
    new.raw_user_meta_data->>'avatar_url'
  )
  on conflict (id) do nothing;
  return new;
end;
$$;
create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.handle_new_user();

-- Atomic Outlook link creation/update.
create or replace function public.link_task_to_outlook_event(
  p_task_id uuid, p_integration_id uuid, p_event_id text, p_calendar_id text,
  p_event_subject text, p_event_start_at timestamptz, p_event_end_at timestamptz,
  p_event_timezone text, p_is_all_day boolean, p_is_cancelled boolean,
  p_event_type text, p_series_master_id text, p_event_last_modified_at timestamptz,
  p_due_at timestamptz, p_due_date date, p_due_is_all_day boolean,
  p_due_timezone text, p_reminder_at timestamptz, p_actor_id uuid
) returns uuid language plpgsql security definer set search_path = public as $$
declare v_link_id uuid; v_workspace_id uuid;
begin
  select workspace_id into v_workspace_id from public.tasks where id=p_task_id for update;
  if v_workspace_id is null then raise exception 'Task not found'; end if;

  insert into public.outlook_event_links(
    task_id,outlook_integration_id,event_id,calendar_id,event_subject,event_start_at,event_end_at,
    event_timezone,is_all_day,is_cancelled,event_type,series_master_id,event_last_modified_at,sync_status,last_sync_at
  ) values (
    p_task_id,p_integration_id,p_event_id,p_calendar_id,p_event_subject,p_event_start_at,p_event_end_at,
    p_event_timezone,p_is_all_day,p_is_cancelled,p_event_type,p_series_master_id,p_event_last_modified_at,
    case when p_is_cancelled then 'EVENT_CANCELLED'::public.outlook_sync_status else 'ACTIVE'::public.outlook_sync_status end,now()
  )
  on conflict(task_id) do update set
    outlook_integration_id=excluded.outlook_integration_id,event_id=excluded.event_id,calendar_id=excluded.calendar_id,
    event_subject=excluded.event_subject,event_start_at=excluded.event_start_at,event_end_at=excluded.event_end_at,
    event_timezone=excluded.event_timezone,is_all_day=excluded.is_all_day,is_cancelled=excluded.is_cancelled,
    event_type=excluded.event_type,series_master_id=excluded.series_master_id,event_last_modified_at=excluded.event_last_modified_at,
    sync_status=excluded.sync_status,last_sync_at=now(),last_error=null,deleted_at=null,updated_at=now()
  returning id into v_link_id;

  update public.tasks set due_source='OUTLOOK',due_at=p_due_at,due_date=p_due_date,due_is_all_day=p_due_is_all_day,
    due_timezone=p_due_timezone,reminder_at=p_reminder_at,reminder_version=reminder_version+1,reminder_sent_at=null,
    updated_by=p_actor_id,updated_at=now() where id=p_task_id;

  insert into public.audit_logs(workspace_id,actor_type,actor_id,entity_type,entity_id,action,metadata)
  values(v_workspace_id,'USER',p_actor_id,'TASK',p_task_id,'OUTLOOK_LINK_CREATED',jsonb_build_object('eventId',p_event_id));
  return v_link_id;
end $$;

create or replace function public.unlink_task_from_outlook_event(p_task_id uuid, p_actor_id uuid)
returns void language plpgsql security definer set search_path = public as $$
declare v_workspace_id uuid;
begin
  select workspace_id into v_workspace_id from public.tasks where id=p_task_id for update;
  update public.outlook_event_links set deleted_at=now(),updated_at=now(),sync_status='DISCONNECTED' where task_id=p_task_id and deleted_at is null;
  update public.tasks set due_source='MANUAL',reminder_version=reminder_version+1,reminder_sent_at=null,updated_by=p_actor_id,updated_at=now() where id=p_task_id;
  insert into public.audit_logs(workspace_id,actor_type,actor_id,entity_type,entity_id,action)
  values(v_workspace_id,'USER',p_actor_id,'TASK',p_task_id,'OUTLOOK_LINK_REMOVED');
end $$;

create or replace function public.apply_outlook_event_sync(
  p_link_id uuid,p_task_id uuid,p_event_subject text,p_event_start_at timestamptz,p_event_end_at timestamptz,
  p_event_timezone text,p_is_all_day boolean,p_is_cancelled boolean,p_event_type text,p_series_master_id text,
  p_event_last_modified_at timestamptz,p_due_at timestamptz,p_due_date date,p_due_is_all_day boolean,
  p_due_timezone text,p_reminder_at timestamptz,p_sync_time timestamptz
) returns void language plpgsql security definer set search_path=public as $$
declare v_workspace_id uuid; v_old_due timestamptz; v_old_date date;
begin
  select workspace_id,due_at,due_date into v_workspace_id,v_old_due,v_old_date from public.tasks where id=p_task_id for update;
  update public.outlook_event_links set
    event_subject=p_event_subject,event_start_at=p_event_start_at,event_end_at=p_event_end_at,event_timezone=p_event_timezone,
    is_all_day=p_is_all_day,is_cancelled=p_is_cancelled,event_type=p_event_type,series_master_id=p_series_master_id,
    event_last_modified_at=p_event_last_modified_at,sync_status=case when p_is_cancelled then 'EVENT_CANCELLED' else 'ACTIVE' end,
    last_sync_at=p_sync_time,last_error=null,updated_at=now()
  where id=p_link_id;
  update public.tasks set
    due_at=p_due_at,due_date=p_due_date,due_is_all_day=p_due_is_all_day,due_timezone=p_due_timezone,
    reminder_at=p_reminder_at,reminder_version=reminder_version+1,reminder_sent_at=null,updated_at=now()
  where id=p_task_id and due_source='OUTLOOK';
  insert into public.audit_logs(workspace_id,actor_type,entity_type,entity_id,action,metadata)
  values(v_workspace_id,'SYSTEM','TASK',p_task_id,'OUTLOOK_EVENT_SYNCED',
    jsonb_build_object('oldDueAt',v_old_due,'oldDueDate',v_old_date,'newDueAt',p_due_at,'newDueDate',p_due_date));
end $$;

create or replace function public.apply_outlook_event_deletion(p_link_id uuid,p_task_id uuid,p_sync_time timestamptz)
returns void language plpgsql security definer set search_path=public as $$
declare v_workspace_id uuid;
begin
  select workspace_id into v_workspace_id from public.tasks where id=p_task_id for update;
  update public.outlook_event_links set sync_status='EVENT_DELETED',last_sync_at=p_sync_time,updated_at=now() where id=p_link_id;
  insert into public.audit_logs(workspace_id,actor_type,entity_type,entity_id,action)
  values(v_workspace_id,'SYSTEM','TASK',p_task_id,'OUTLOOK_EVENT_DELETED');
end $$;

-- Atomic reminder claim. Sets reminder_sent_at before side effects to prevent duplicate sends.
create or replace function public.claim_task_reminder(p_task_id uuid,p_expected_version integer,p_claimed_at timestamptz)
returns boolean language plpgsql security definer set search_path=public as $$
declare v_count integer;
begin
  update public.tasks set reminder_sent_at=p_claimed_at
  where id=p_task_id and reminder_version=p_expected_version and reminder_sent_at is null
    and reminder_enabled=true and status not in ('DONE','CANCELLED');
  get diagnostics v_count = row_count;
  return v_count = 1;
end $$;

-- Row Level Security. The Worker uses service-role credentials, but direct browser access remains scoped.
alter table public.profiles enable row level security;
alter table public.workspaces enable row level security;
alter table public.workspace_members enable row level security;
alter table public.pages enable row level security;
alter table public.tasks enable row level security;
alter table public.outlook_integrations enable row level security;
alter table public.graph_subscriptions enable row level security;
alter table public.outlook_event_links enable row level security;
alter table public.notifications enable row level security;
alter table public.audit_logs enable row level security;

create or replace function public.is_workspace_member(p_workspace_id uuid)
returns boolean language sql stable security definer set search_path=public as $$
  select exists(select 1 from public.workspace_members wm where wm.workspace_id=p_workspace_id and wm.user_id=auth.uid());
$$;

create or replace function public.workspace_role_for(p_workspace_id uuid)
returns public.workspace_role language sql stable security definer set search_path=public as $$
  select role from public.workspace_members where workspace_id=p_workspace_id and user_id=auth.uid();
$$;

create policy profiles_self_read on public.profiles for select using (id=auth.uid());
create policy profiles_self_update on public.profiles for update using (id=auth.uid()) with check(id=auth.uid());

-- Allows first authenticated user to create a workspace they own.
create policy workspace_create on public.workspaces for insert to authenticated with check (created_by=auth.uid());
create policy workspace_member_read on public.workspaces for select using (public.is_workspace_member(id) or created_by=auth.uid());
create policy workspace_owner_bootstrap_update on public.workspaces for update using (public.workspace_role_for(id)='ADMIN');

create policy membership_read on public.workspace_members for select using (user_id=auth.uid() or public.is_workspace_member(workspace_id));
-- Bootstrap: creator may insert themselves as ADMIN immediately after creating a workspace.
create policy membership_bootstrap_insert on public.workspace_members for insert to authenticated with check (
  user_id=auth.uid() and (
    role='ADMIN' and exists(select 1 from public.workspaces w where w.id=workspace_id and w.created_by=auth.uid())
    or public.workspace_role_for(workspace_id)='ADMIN'
  )
);
create policy membership_admin_update on public.workspace_members for update using (public.workspace_role_for(workspace_id)='ADMIN');
create policy membership_admin_delete on public.workspace_members for delete using (public.workspace_role_for(workspace_id)='ADMIN');

create policy pages_member_read on public.pages for select using (public.is_workspace_member(workspace_id));
create policy tasks_member_read on public.tasks for select using (public.is_workspace_member(workspace_id));
create policy notifications_self_read on public.notifications for select using (user_id=auth.uid());
create policy audit_member_read on public.audit_logs for select using (public.is_workspace_member(workspace_id));
create policy outlook_member_read on public.outlook_integrations for select using (public.is_workspace_member(workspace_id));
create policy outlook_link_member_read on public.outlook_event_links for select using (
  exists(select 1 from public.tasks t where t.id=task_id and public.is_workspace_member(t.workspace_id))
);
