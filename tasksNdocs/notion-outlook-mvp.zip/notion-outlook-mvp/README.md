# Notion + Shared Outlook Calendar MVP

Runnable starter implementation for the technical proposal:

- React + TypeScript + Vite frontend
- Cloudflare Worker REST API
- Cloudflare Queue consumer for Microsoft Graph notifications
- Cloudflare Cron for reminders, reconciliation, and subscription renewal
- Supabase PostgreSQL/Auth/Realtime
- Microsoft Graph application authentication for an organization-owned shared/delegated mailbox calendar
- Resend-compatible email reminder adapter

## Architecture

```text
React/Vite ──HTTPS──> Cloudflare Worker API ──> Supabase PostgreSQL
                            │
                            ├──> Microsoft Graph
                            │       │
                            │       └── webhook ──> Worker ──> Queue ──> sync consumer
                            │
                            └── Cron ──> reminders / reconciliation / subscription renewal
```

## Important Microsoft assumption

The implemented webhook path is for a shared/delegated Exchange mailbox calendar using **application** calendar permission. Delegated `Calendars.Read.Shared` can read a shared calendar but cannot subscribe to change notifications in that shared/delegated folder.

For production, scope the Graph service principal to the required mailbox using Exchange Online RBAC for Applications rather than leaving tenant-wide mailbox access unrestricted.

## Prerequisites

- Node.js 22+
- pnpm 10+
- Cloudflare account
- Supabase project
- Microsoft Entra app registration
- Microsoft 365 administrator able to grant the required application permission / Exchange RBAC assignment
- Optional Resend account for email reminders

## 1. Install

```bash
corepack enable
pnpm install
```

## 2. Create the database

Apply:

```text
supabase/migrations/0001_initial.sql
```

through the Supabase SQL editor or Supabase CLI.

Create at least one workspace and membership row after the first user logs in. The SQL file contains a helper trigger that automatically creates the user's profile, but workspace creation is intentionally explicit.

## 3. Configure frontend

```bash
cp apps/web/.env.example apps/web/.env.local
```

Set:

```text
VITE_SUPABASE_URL=
VITE_SUPABASE_ANON_KEY=
VITE_API_BASE_URL=http://localhost:8787
```

Enable the Azure/Microsoft provider in Supabase Auth if you want the `Continue with Microsoft` button to work. Configure the organization-specific Azure tenant URL and allow the `email` scope. Email magic link login also works.

## 4. Configure Worker secrets

```bash
cd apps/worker
cp .dev.vars.example .dev.vars
```

Set all required values. For deployed environments use `wrangler secret put` rather than committing secrets.

## 5. Create Cloudflare Queue

```bash
pnpm exec wrangler queues create calendar-sync
pnpm exec wrangler queues create calendar-sync-dlq
```

The queue binding name in `wrangler.jsonc` is `CALENDAR_SYNC_QUEUE`.

## 6. Run locally

Terminal 1:

```bash
pnpm dev:worker
```

Terminal 2:

```bash
pnpm dev:web
```

## 7. Configure Microsoft Graph

The Entra application needs application calendar read capability for the target Exchange mailbox. The Worker uses the OAuth client-credentials flow and `https://graph.microsoft.com/.default`.

Set:

```text
MICROSOFT_TENANT_ID
MICROSOFT_CLIENT_ID
MICROSOFT_CLIENT_SECRET
MICROSOFT_MAILBOX_UPN
MICROSOFT_CALENDAR_ID
GRAPH_CLIENT_STATE
WEBHOOK_BASE_URL
```

After deployment, create/renew the subscription from:

```http
POST /api/v1/admin/outlook/subscription/renew
```

with an authenticated workspace `ADMIN` session.

The Worker subscribes to:

```text
/users/{mailbox}/events
```

and uses basic notifications. It re-reads the event from Graph before updating any task.

## 8. Production security checklist

- Use Exchange Online RBAC for Applications to scope the Graph app to the required mailbox.
- Use Cloudflare secrets for service credentials.
- Never put the Supabase service-role key in the browser.
- Restrict workspace membership and keep RLS enabled.
- Configure a custom domain/HTTPS webhook URL before creating Graph subscriptions.
- Rotate `GRAPH_CLIENT_STATE` if it is exposed.

## Implemented MVP endpoints

```text
GET    /health
GET    /api/v1/pages
POST   /api/v1/pages
GET    /api/v1/tasks
POST   /api/v1/tasks
PATCH  /api/v1/tasks/:id
GET    /api/v1/outlook/status
GET    /api/v1/outlook/events
POST   /api/v1/tasks/:id/outlook-link
DELETE /api/v1/tasks/:id/outlook-link
POST   /api/v1/admin/outlook/verify
POST   /api/v1/admin/outlook/resync
POST   /api/v1/admin/outlook/subscription/renew
POST   /webhooks/microsoft/events
POST   /webhooks/microsoft/lifecycle
```

## Intentional MVP limitations

- One primary assignee per task.
- Task due date is one-way Outlook -> app while linked.
- Task links to one Outlook event.
- Recurring meetings should be linked to a concrete occurrence.
- No Notion database/formula system.
- No multiplayer document CRDT.
- Reconciliation currently checks active linked events directly; delta sync can be added later.
